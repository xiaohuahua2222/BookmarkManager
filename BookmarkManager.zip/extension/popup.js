/* ============================================================
 * popup.js — 收藏面板
 *
 * 流程：读配置 → 取当前标签页 → 加载分类树 → 一二级分类默认留空（由用户主动选择）→ 收藏
 * 所有插入到 DOM 的页面数据（标题、URL）一律用 textContent / value，
 * 不使用 innerHTML，避免页面标题里的标签被当作 HTML 解析。
 * ============================================================ */

import { api, ApiError, clearAuth, isConfigured, readConfig, writeConfig } from './api.js';

const $ = (id) => document.getElementById(id);

const els = {
  viewSetup: $('view-setup'),
  setupMessage: $('setup-message'),
  btnOpenOptions: $('btn-open-options'),

  viewUnsupported: $('view-unsupported'),
  unsupportedReason: $('unsupported-reason'),

  viewForm: $('view-form'),
  accountName: $('account-name'),
  btnSettings: $('btn-settings'),
  pageIcon: $('page-icon'),
  pageHost: $('page-host'),
  pageUrl: $('page-url'),
  inputTitle: $('input-title'),
  inputDesc: $('input-desc'),
  selectL1: $('select-l1'),
  btnNewL1: $('btn-new-l1'),
  selectL2: $('select-l2'),
  btnNewL2: $('btn-new-l2'),
  btnAi: $('btn-ai'),
  catNew: $('cat-new'),
  catNewName: $('cat-new-name'),
  catNewOk: $('cat-new-ok'),
  catNewCancel: $('cat-new-cancel'),
  catHint: $('cat-hint'),
  publicSegment: $('public-segment'),
  publicHint: $('public-hint'),
  message: $('message'),
  btnSave: $('btn-save'),

  viewDone: $('view-done'),
  doneIcon: $('done-icon'),
  doneTitle: $('done-title'),
  doneDetail: $('done-detail'),
  doneNote: $('done-note'),
  btnDoneClose: $('btn-done-close'),
};

const state = {
  config: null,
  tab: null,
  categories: [],
  isPublic: 1,
  newTarget: '', // 'l1' | 'l2'
  saving: false,
  ai: { enabled: false, loading: false }, // AI 分类：enabled 来自 /api/ai_status，loading 为请求中
};

// AI 临时分类节点的负数 id 序列（保存时才落盘换成真实 id）
let tempSeq = 0;
function nextTempId() {
  return --tempSeq;
}

/* ---------------- 视图切换 ---------------- */

function showView(name) {
  els.viewSetup.hidden = name !== 'setup';
  els.viewUnsupported.hidden = name !== 'unsupported';
  els.viewForm.hidden = name !== 'form';
  els.viewDone.hidden = name !== 'done';
}

function showMessage(text, kind) {
  if (!text) {
    els.message.hidden = true;
    els.message.textContent = '';
    return;
  }
  els.message.textContent = text;
  els.message.className = `message ${kind || ''}`.trim();
  els.message.hidden = false;
}

/* ---------------- 启动 ---------------- */

async function init() {
  bindEvents();

  state.config = await readConfig();
  if (!isConfigured(state.config)) {
    showView('setup');
    return;
  }

  if (!(await loadCurrentTab())) {
    showView('unsupported');
    return;
  }

  renderAccount();
  renderPreview();
  showView('form');

  await loadCategories();
  prefill();
  loadPageDescription(); // 异步补充描述，不阻塞界面
  loadAiStatus(); // 异步查询 AI 是否启用，不阻塞界面
}

function bindEvents() {
  els.btnOpenOptions.addEventListener('click', openOptions);
  els.btnSettings.addEventListener('click', openOptions);

  els.selectL1.addEventListener('change', () => {
    renderL2();
    updatePublicHint();
  });
  els.selectL2.addEventListener('change', updatePublicHint);

  els.btnNewL1.addEventListener('click', () => openNewCategory('l1'));
  els.btnNewL2.addEventListener('click', () => openNewCategory('l2'));
  els.btnAi.addEventListener('click', aiClassify);
  els.catNewOk.addEventListener('click', createCategory);
  els.catNewCancel.addEventListener('click', closeNewCategory);
  els.catNewName.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      createCategory();
    } else if (event.key === 'Escape') {
      closeNewCategory();
    }
  });

  els.publicSegment.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-public]');
    if (!button) return;
    setPublic(Number(button.dataset.public));
  });

  els.inputTitle.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      save();
    }
  });

  els.btnSave.addEventListener('click', save);
  els.btnDoneClose.addEventListener('click', () => window.close());
}

function openOptions() {
  chrome.runtime.openOptionsPage();
}

/* ---------------- 当前标签页 ---------------- */

async function loadCurrentTab() {
  let tabs = [];
  try {
    tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  } catch {
    tabs = [];
  }

  const tab = tabs && tabs[0];
  if (!tab || !tab.url) {
    els.unsupportedReason.textContent = '没有读取到当前页面地址，请刷新页面后重试。';
    return false;
  }

  if (!/^https?:\/\//i.test(tab.url)) {
    els.unsupportedReason.textContent =
      '浏览器的内部页面（如设置页、扩展页、新标签页）无法收藏，请切换到普通网页后再试。';
    return false;
  }

  state.tab = tab;
  return true;
}

function renderAccount() {
  const user = state.config.user;
  els.accountName.textContent = (user && (user.displayName || user.username)) || '已连接';
}

function renderPreview() {
  let host = '';
  try {
    host = new URL(state.tab.url).hostname;
  } catch {
    host = '';
  }

  els.pageHost.textContent = host;
  els.pageUrl.textContent = state.tab.url;
  els.inputTitle.value = String(state.tab.title || host || '').trim();

  const icon = state.tab.favIconUrl;
  if (icon && /^https?:\/\//i.test(icon)) {
    els.pageIcon.src = icon;
    els.pageIcon.hidden = false;
    els.pageIcon.addEventListener('error', () => {
      els.pageIcon.hidden = true;
    });
  }
}

/**
 * 从页面 meta 标签补充描述。
 * 受限页面（PDF、商店页等）会拒绝注入，忽略即可。
 */
async function loadPageDescription() {
  try {
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId: state.tab.id },
      func: () => {
        const pick = (selector) => {
          const el = document.querySelector(selector);
          return el ? String(el.getAttribute('content') || '').trim() : '';
        };
        return (
          pick('meta[name="description"]') ||
          pick('meta[property="og:description"]') ||
          pick('meta[name="twitter:description"]')
        );
      },
    });

    const description = (injection && injection.result) || '';
    if (description && !els.inputDesc.value.trim()) {
      els.inputDesc.value = description.slice(0, 500);
    }
  } catch {
    /* 无法注入就留空，由用户自行填写 */
  }
}

/* ---------------- 分类树 ---------------- */

async function loadCategories() {
  try {
    const tree = await api.categories(state.config);
    state.categories = Array.isArray(tree) ? tree.map(normalizeCategory) : [];
  } catch (error) {
    if (error instanceof ApiError && error.isAuthError) {
      await handleAuthExpired();
      return;
    }
    state.categories = [];
    showMessage(error.message, 'error');
  }
  renderL1();
}

/** 统一把分类节点的公开状态转成数字，避免字符串比较踩坑 */
function normalizeCategory(node) {
  return {
    id: Number(node.id),
    name: node.name || '',
    isPublic: Number(node.isPublic || 0),
    children: Array.isArray(node.children) ? node.children.map(normalizeCategory) : [],
  };
}

function renderL1() {
  els.selectL1.textContent = '';

  if (state.categories.length === 0) {
    els.selectL1.add(new Option('（没有目录）', '0'));
    els.selectL1.disabled = true;
    els.catHint.textContent = '账号下还没有目录，点右侧「+」新建一个一级目录即可收藏。';
    els.catHint.hidden = false;
  } else {
    els.selectL1.disabled = false;
    els.catHint.hidden = true;
    // 默认留空占位项，不自动选中第一个目录，强制用户主动选择，避免误收藏
    els.selectL1.add(new Option('请选择一级目录', '0'));
    for (const item of state.categories) {
      els.selectL1.add(new Option(item.name, String(item.id)));
    }
    els.selectL1.value = '0';
  }

  renderL2();
}

function renderL2() {
  const parent = findL1(Number(els.selectL1.value));
  const children = parent ? parent.children : [];

  els.selectL2.textContent = '';

  // 尚未选择一级目录时，二级同样留空且不可用
  if (!parent) {
    els.selectL2.add(new Option('请先选一级目录', '0'));
    els.selectL2.disabled = true;
    els.btnNewL2.disabled = true;
    return;
  }

  els.selectL2.add(new Option('不指定二级目录', '0'));
  for (const child of children) {
    els.selectL2.add(new Option(child.name, String(child.id)));
  }

  els.selectL2.disabled = children.length === 0;
  els.btnNewL2.disabled = false;
}

function findL1(id) {
  return state.categories.find((item) => item.id === id) || null;
}

function findL2(parentId, id) {
  const parent = findL1(parentId);
  return parent ? parent.children.find((item) => item.id === id) || null : null;
}

/* ---------------- 默认偏好（分类留空，仅沿用可见性） ---------------- */

function prefill() {
  // 一二级分类默认留空（renderL1 / renderL2 已给出占位项），每次打开都由用户主动选择，
  // 不再回填上次选择或自动选中第一个目录；仅保留上次可见性偏好。
  const accountDefault = state.config.user ? Number(state.config.user.linkPublicDefault) : NaN;
  const fallback = accountDefault === 0 || accountDefault === 1 ? accountDefault : 1;
  setPublic(typeof state.config.lastPublic === 'number' ? state.config.lastPublic : fallback);
}

/* ---------------- 可见性 ---------------- */

function setPublic(value) {
  state.isPublic = value === 1 ? 1 : 0;
  for (const button of els.publicSegment.querySelectorAll('button[data-public]')) {
    button.classList.toggle('active', Number(button.dataset.public) === state.isPublic);
  }
  updatePublicHint();
}

/** 所选目录（含上级）是否允许公开 */
function isCategoryChainPublic() {
  const l1 = findL1(Number(els.selectL1.value));
  if (!l1) return false;
  if (l1.isPublic !== 1) return false;

  const l2Id = Number(els.selectL2.value);
  if (l2Id > 0) {
    const l2 = findL2(l1.id, l2Id);
    if (!l2 || l2.isPublic !== 1) return false;
  }
  return true;
}

function updatePublicHint() {
  // 未选择一级目录时不提示（此时分类为空，谈不上公开/私有冲突）
  const l1 = findL1(Number(els.selectL1.value));
  if (state.isPublic === 1 && l1 && !isCategoryChainPublic()) {
    els.publicHint.textContent = '所选目录为私有，保存时会自动按私有处理。';
    els.publicHint.hidden = false;
    return;
  }
  els.publicHint.hidden = true;
}

/* ---------------- 新建目录 ---------------- */

function openNewCategory(target) {
  state.newTarget = target;
  els.catNew.hidden = false;
  els.catNewName.value = '';
  els.catNewName.placeholder = target === 'l2' ? '新二级目录名称' : '新一级目录名称';
  els.catNewName.focus();
}

function closeNewCategory() {
  state.newTarget = '';
  els.catNew.hidden = true;
  els.catNewName.value = '';
}

async function createCategory() {
  const name = els.catNewName.value.trim();
  if (!name) {
    els.catNewName.focus();
    return;
  }

  const target = state.newTarget;
  const parentId = target === 'l2' ? Number(els.selectL1.value) || 0 : 0;
  if (target === 'l2' && !parentId) {
    showMessage('请先选择一级目录，再新建二级目录。', 'error');
    return;
  }

  els.catNewOk.disabled = true;
  try {
    const created = await api.createCategory(
      {
        parent_id: parentId,
        name,
        description: '',
        icon: '',
        icon_color: '',
        sort_order: 0,
        // 跟随当前可见性选择，省去再改一次目录公开状态
        is_public: state.isPublic,
      },
      state.config
    );

    await loadCategories();

    if (target === 'l2') {
      els.selectL1.value = String(parentId);
      renderL2();
      els.selectL2.value = String(created.id);
    } else {
      els.selectL1.value = String(created.id);
      renderL2();
    }

    closeNewCategory();
    showMessage(`目录「${name}」已创建`, 'ok');
  } catch (error) {
    if (error instanceof ApiError && error.isAuthError) {
      await handleAuthExpired();
      return;
    }
    showMessage(error.message, 'error');
  } finally {
    els.catNewOk.disabled = false;
  }
}

/* ---------------- AI 分类 ---------------- */

async function loadAiStatus() {
  try {
    const s = await api.aiStatus(state.config);
    state.ai.enabled = !!(s && s.enabled);
  } catch {
    state.ai.enabled = false;
  }
  updateAiButton();
}

function updateAiButton() {
  els.btnAi.disabled = state.ai.loading || !state.ai.enabled;
  els.btnAi.textContent = state.ai.loading ? '识别中…' : 'AI分类';
  els.btnAi.title = state.ai.enabled
    ? '根据当前页面让 AI 推荐分类'
    : 'AI 未启用，请先在网站系统设置中配置';
}

async function aiClassify() {
  if (!state.tab || !state.tab.url) {
    showMessage('没有可识别的页面地址', 'error');
    return;
  }

  state.ai.loading = true;
  updateAiButton();
  try {
    const res = await api.aiClassify(state.tab.url, state.config);
    const name = ((res && res.name) || '').trim();
    if (!name) {
      showMessage('AI 未返回有效分类', 'error');
      return;
    }
    applyAiCategory(name);
    showMessage('AI 分类完成，点「收藏」后生效', 'ok');
  } catch (error) {
    if (error instanceof ApiError && error.isAuthError) {
      await handleAuthExpired();
      return;
    }
    showMessage(error.message, 'error');
  } finally {
    state.ai.loading = false;
    updateAiButton();
  }
}

/**
 * 把 AI 建议落到下拉选择：一级目录选中/新建「AI自动分类」，二级目录选中/新建 AI 返回名。
 * 新建的都是一级/二级临时节点（负数 id），要到点「收藏」时才落盘。
 */
function applyAiCategory(name) {
  const L1 = 'AI自动分类';
  let l1 = state.categories.find((c) => c.name === L1);
  if (!l1) {
    l1 = { id: nextTempId(), name: L1, isPublic: state.isPublic, children: [], temp: true };
    state.categories.push(l1);
    renderL1(); // 重建一级列表以包含新节点
  }
  els.selectL1.value = String(l1.id);
  renderL2();

  if (!Array.isArray(l1.children)) l1.children = [];
  let l2 = l1.children.find((s) => s.name === name);
  if (!l2) {
    l2 = { id: nextTempId(), name, isPublic: state.isPublic, children: [], temp: true };
    l1.children.push(l2);
    renderL2();
  }
  els.selectL2.value = String(l2.id);
  els.selectL2.disabled = false;
  updatePublicHint();
}

/** 按下拉选中的 id（含负数临时 id）找到对应分类节点；传 parentNode 则在其子级里找 */
function findNodeById(id, parentNode) {
  if (parentNode) {
    return (parentNode.children || []).find((c) => c.id === id) || null;
  }
  return state.categories.find((c) => c.id === id) || null;
}

/**
 * 保存时落盘临时分类节点：非临时直接返回原节点；
 * 临时节点先 POST /api/categories 建好（is_public 跟随当前链接）再换成真实 id。
 */
async function persistTempNode(selectedId, parentId, parentNode) {
  const node = findNodeById(selectedId, parentNode);
  if (!node || !node.temp) return node;

  const created = await api.createCategory(
    {
      parent_id: parentId,
      name: node.name,
      description: '',
      icon: '',
      icon_color: '',
      sort_order: 0,
      is_public: state.isPublic,
    },
    state.config
  );

  node.id = Number(created.id);
  node.isPublic = state.isPublic;
  delete node.temp;
  return node;
}

/** 临时节点落盘后 id 变了，把下拉里对应项的 value 换成真实 id 并保持选中（避免重试图引用失效的负数 id） */
function reselect(select, oldId, newId) {
  if (!newId || oldId === newId) return;
  const opt = select.querySelector(`option[value="${oldId}"]`);
  if (opt) opt.value = String(newId);
  select.value = String(newId);
}

/* ---------------- 收藏 ---------------- */

async function save() {
  if (state.saving) return;

  const title = els.inputTitle.value.trim();
  if (!title) {
    showMessage('标题不能为空', 'error');
    els.inputTitle.focus();
    return;
  }

  const l1Sel = Number(els.selectL1.value) || 0;
  if (!l1Sel) {
    showMessage('请先选择一个目录', 'error');
    return;
  }

  const l2Sel = Number(els.selectL2.value) || 0;

  setSaving(true);
  showMessage('');

  try {
    // AI 生成的临时目录（负数 id）到点收藏时才落盘，与网页端一致
    const l1Node = await persistTempNode(l1Sel, 0);
    const l1Id = l1Node ? l1Node.id : l1Sel;
    reselect(els.selectL1, l1Sel, l1Id);
    let l2Id = 0;
    if (l2Sel !== 0) {
      const l2Node = await persistTempNode(l2Sel, l1Id, l1Node);
      l2Id = l2Node ? l2Node.id : l2Sel;
      reselect(els.selectL2, l2Sel, l2Id);
    }

    const categoryType = l2Id > 0 ? 'l2' : 'l1';
    const categoryId = l2Id > 0 ? l2Id : l1Id;

    const result = await api.addLink(
      {
        title,
        url: state.tab.url,
        description: els.inputDesc.value.trim(),
        category_type: categoryType,
        category_id: categoryId,
        is_public: state.isPublic,
      },
      state.config
    );

    // 记住本次选择：供 background 右键「快速收藏」沿用到同一目录（弹窗表单仍默认留空，不回填）
    await writeConfig({
      lastCategory: { type: categoryType, id: categoryId },
      lastPublic: state.isPublic,
    });

    showDone(result, categoryType, categoryId);
  } catch (error) {
    setSaving(false);
    if (error instanceof ApiError && error.isAuthError) {
      await handleAuthExpired();
      return;
    }
    showMessage(error.message, 'error');
  }
}

function setSaving(saving) {
  state.saving = saving;
  els.btnSave.disabled = saving;
  els.btnSave.textContent = saving ? '收藏中…' : '收藏';
}

function categoryPath(categoryType, categoryId) {
  if (categoryType === 'l2') {
    for (const item of state.categories) {
      const hit = item.children.find((child) => child.id === categoryId);
      if (hit) return `${item.name} / ${hit.name}`;
    }
  }
  const l1 = findL1(categoryId);
  return l1 ? l1.name : '未知目录';
}

function showDone(result, categoryType, categoryId) {
  const created = !result || result.created !== false;
  const finalPublic = result && Number(result.isPublic) === 1 ? 1 : 0;
  const path = categoryPath(categoryType, categoryId);

  if (created) {
    els.doneIcon.textContent = '✓';
    els.doneIcon.classList.remove('warn');
    els.doneTitle.textContent = '已收藏';
  } else {
    els.doneIcon.textContent = 'i';
    els.doneIcon.classList.add('warn');
    els.doneTitle.textContent = '之前已经收藏过';
  }

  els.doneDetail.textContent = [path, finalPublic === 1 ? '公开' : '私有'].join(' · ');

  let note = '';
  if (!created) {
    note = '同一地址在书签库里已存在，本次没有重复添加。';
  } else if (finalPublic !== state.isPublic) {
    note = '所选目录为私有，已自动按私有保存。';
  }
  els.doneNote.textContent = note;
  els.doneNote.hidden = !note;

  showView('done');

  // 新建节点成功后不立刻关窗，留一点时间让用户看清结果
  if (created) setTimeout(() => window.close(), 1800);
}

/* ---------------- 登录态失效 ---------------- */

async function handleAuthExpired() {
  await clearAuth();
  state.config = await readConfig();
  els.setupMessage.textContent = '登录已过期，请重新登录后再收藏。';
  els.setupMessage.hidden = false;
  showView('setup');
}

init();
