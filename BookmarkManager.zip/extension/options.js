/* ============================================================
 * options.js — 设置页
 *
 * 两种认证方式：
 *   1. 账号密码登录 → 换取会话令牌（JWT，7 天）
 *   2. 直接填 API 令牌（bmt_，长期有效）
 * 两者都存成统一的 token，后续请求一律 Bearer 发送。
 * ============================================================ */

import {
  api,
  ApiError,
  clearAuth,
  DEFAULT_BASE_URL,
  normalizeBaseUrl,
  readConfig,
  writeConfig,
} from './api.js';

const $ = (id) => document.getElementById(id);

const els = {
  inputBase: $('input-base'),
  btnTest: $('btn-test'),
  baseStatus: $('base-status'),

  accountInfo: $('account-info'),
  accountForms: $('account-forms'),
  infoName: $('info-name'),
  infoUsername: $('info-username'),
  infoRole: $('info-role'),
  infoKind: $('info-kind'),
  infoExpiry: $('info-expiry'),
  infoDefault: $('info-default'),
  btnRefresh: $('btn-refresh'),
  btnLogout: $('btn-logout'),

  tabs: document.querySelector('.tabs'),
  panePassword: $('pane-password'),
  paneApikey: $('pane-apikey'),
  inputUsername: $('input-username'),
  inputPassword: $('input-password'),
  btnLogin: $('btn-login'),
  inputToken: $('input-token'),
  btnSaveToken: $('btn-save-token'),

  message: $('message'),
};

let messageTimer = 0;

/* ---------------- 通用 ---------------- */

function showMessage(text, kind) {
  clearTimeout(messageTimer);
  if (!text) {
    els.message.hidden = true;
    return;
  }
  els.message.textContent = text;
  els.message.className = `message ${kind || ''}`.trim();
  els.message.hidden = false;
  messageTimer = setTimeout(() => {
    els.message.hidden = true;
  }, 3800);
}

function setBusy(button, busy, text) {
  button.disabled = busy;
  button.textContent = text;
}

function setBaseStatus(text, kind) {
  els.baseStatus.textContent = text || '';
  els.baseStatus.className = `hint ${kind || ''}`.trim();
  els.baseStatus.hidden = !text;
}

/* ---------------- 启动 ---------------- */

async function init() {
  bindEvents();

  const cfg = await readConfig();
  els.inputBase.value = cfg.baseUrl;

  if (cfg.token) {
    await refreshAccount();
  } else {
    renderLoggedOut();
  }
}

function bindEvents() {
  els.tabs.addEventListener('click', (event) => {
    const button = event.target.closest('button[data-tab]');
    if (!button) return;
    switchTab(button.dataset.tab);
  });

  els.inputBase.addEventListener('change', onBaseUrlChanged);
  els.btnTest.addEventListener('click', testConnection);
  els.btnLogin.addEventListener('click', login);
  els.btnSaveToken.addEventListener('click', saveToken);
  els.btnRefresh.addEventListener('click', async () => {
    await refreshAccount();
    showMessage('账号信息已刷新', 'ok');
  });
  els.btnLogout.addEventListener('click', logout);

  els.inputPassword.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') login();
  });
  els.inputToken.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') saveToken();
  });
}

function switchTab(name) {
  for (const button of els.tabs.querySelectorAll('button[data-tab]')) {
    button.classList.toggle('active', button.dataset.tab === name);
  }
  els.panePassword.hidden = name !== 'password';
  els.paneApikey.hidden = name !== 'apikey';
}

/* ---------------- 渲染 ---------------- */

function renderLoggedIn(cfg, warn) {
  const user = cfg.user || {};

  els.accountInfo.hidden = false;
  els.accountForms.hidden = true;

  els.infoName.textContent = user.displayName || user.username || '—';
  els.infoUsername.textContent = user.username || '—';
  els.infoRole.textContent = user.role === 'admin' ? '管理员' : '普通用户';
  els.infoKind.textContent = cfg.tokenKind === 'apikey' ? 'API 令牌' : '账号密码登录';
  els.infoExpiry.textContent = describeToken(cfg);
  els.infoDefault.textContent = Number(user.linkPublicDefault) === 0 ? '私有' : '公开';

  if (warn) showMessage(warn, 'error');
}

function renderLoggedOut() {
  els.accountInfo.hidden = true;
  els.accountForms.hidden = false;
}

/** 令牌有效期描述：API 令牌长期有效，会话令牌解析 JWT 的 exp */
function describeToken(cfg) {
  if (cfg.tokenKind === 'apikey') return '长期有效';

  const expiry = jwtExpiry(cfg.token);
  if (!expiry) return '会话令牌';

  const text = expiry.toLocaleString('zh-CN', { hour12: false });
  const days = Math.ceil((expiry.getTime() - Date.now()) / 86400000);
  return days > 0 ? `有效至 ${text}（约 ${days} 天）` : `已于 ${text} 过期`;
}

/** 解析 JWT payload 中的 exp，仅用于展示，不做校验 */
function jwtExpiry(token) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3) return null;
  try {
    let payload = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    payload = payload.padEnd(payload.length + ((4 - (payload.length % 4)) % 4), '=');
    const json = JSON.parse(atob(payload));
    return json.exp ? new Date(json.exp * 1000) : null;
  } catch {
    return null;
  }
}

/* ---------------- 服务端地址 ---------------- */

async function onBaseUrlChanged() {
  const baseUrl = normalizeBaseUrl(els.inputBase.value) || DEFAULT_BASE_URL;
  els.inputBase.value = baseUrl;

  const cfg = await readConfig();
  if (baseUrl === cfg.baseUrl) return;

  // 地址变了：旧令牌不一定还认，先验证一次再决定去留
  if (!cfg.token) {
    await writeConfig({ baseUrl });
    setBaseStatus('地址已保存', 'ok');
    return;
  }

  try {
    const user = await api.me({ baseUrl, token: cfg.token });
    await writeConfig({ baseUrl, user });
    renderLoggedIn({ ...cfg, baseUrl, user });
    setBaseStatus('地址已更新，登录仍然有效', 'ok');
  } catch (error) {
    if (error instanceof ApiError && error.isAuthError) {
      await clearAuth();
      await writeConfig({ baseUrl });
      renderLoggedOut();
      showMessage('新地址下登录已失效，请重新登录', 'error');
      setBaseStatus('');
      return;
    }
    els.inputBase.value = cfg.baseUrl;
    setBaseStatus(error.message, 'error');
  }
}

async function testConnection() {
  const baseUrl = normalizeBaseUrl(els.inputBase.value) || DEFAULT_BASE_URL;
  setBusy(els.btnTest, true, '测试中…');
  try {
    const info = await api.initStatus({ baseUrl });
    setBaseStatus(`连接成功：${info.siteName || '书签库'}`, 'ok');
  } catch (error) {
    setBaseStatus(error.message, 'error');
  } finally {
    setBusy(els.btnTest, false, '测试连接');
  }
}

/* ---------------- 登录 / 令牌 ---------------- */

async function login() {
  const baseUrl = normalizeBaseUrl(els.inputBase.value) || DEFAULT_BASE_URL;
  const username = els.inputUsername.value.trim();
  const password = els.inputPassword.value;

  if (!username || !password) {
    showMessage('请输入用户名和密码', 'error');
    return;
  }

  setBusy(els.btnLogin, true, '登录中…');
  try {
    const result = await api.login(username, password, { baseUrl, token: '' });
    await writeConfig({
      baseUrl,
      token: result.token,
      tokenKind: 'session',
      user: result.user || null,
    });

    els.inputPassword.value = '';
    els.inputBase.value = baseUrl;
    await refreshAccount();
    showMessage('登录成功', 'ok');
  } catch (error) {
    showMessage(error.message, 'error');
  } finally {
    setBusy(els.btnLogin, false, '登录');
  }
}

async function saveToken() {
  const baseUrl = normalizeBaseUrl(els.inputBase.value) || DEFAULT_BASE_URL;
  const token = els.inputToken.value.trim();

  if (!token) {
    showMessage('请填写 API 令牌', 'error');
    return;
  }

  setBusy(els.btnSaveToken, true, '验证中…');
  try {
    // 先拿令牌换一次账号信息，确认令牌真的可用再落盘
    const user = await api.me({ baseUrl, token });
    await writeConfig({ baseUrl, token, tokenKind: 'apikey', user: user || null });

    els.inputToken.value = '';
    renderLoggedIn({ baseUrl, token, tokenKind: 'apikey', user });
    showMessage('令牌有效，已保存', 'ok');
  } catch (error) {
    showMessage(error.message, 'error');
  } finally {
    setBusy(els.btnSaveToken, false, '保存并验证');
  }
}

async function refreshAccount() {
  const cfg = await readConfig();
  if (!cfg.token) {
    renderLoggedOut();
    return;
  }

  try {
    const user = await api.me(cfg);
    await writeConfig({ user });
    renderLoggedIn({ ...cfg, user });
  } catch (error) {
    if (error instanceof ApiError && error.isAuthError) {
      await clearAuth();
      renderLoggedOut();
      showMessage('登录已失效，请重新登录', 'error');
      return;
    }
    // 网络问题：保留已连接的展示，只提示错误
    renderLoggedIn(cfg, `暂时无法校验登录状态：${error.message}`);
  }
}

async function logout() {
  await clearAuth();
  const cfg = await readConfig();
  els.inputBase.value = cfg.baseUrl;
  renderLoggedOut();
  showMessage('已退出登录', 'ok');
}

init();
