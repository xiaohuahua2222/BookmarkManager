/* ============================================================
 * api.js — 扩展共享模块：配置存储 + 开放 API 客户端
 *
 * 后端响应信封实际为 { Code, Msg, Data }（C# record 原名，未改驼峰），
 * 而 Data 内部又是 snake_case（JsonPropertyName）与 PascalCase 混用，
 * 因此这里统一在 norm() 中规整为 camelCase，界面层只消费驼峰字段。
 *
 * 认证：Authorization: Bearer <token>
 *   - 后台「工具」页生成的 API 令牌（bmt_ 前缀，长期有效）
 *   - 或用户名密码登录换取的会话令牌（JWT，7 天有效）
 * 两者后端均支持，扩展不区分处理。
 * ============================================================ */

/** 默认服务端地址（可在扩展设置页修改） */
export const DEFAULT_BASE_URL = 'http://localhost:3080';

/** chrome.storage.local 使用的键 */
const CONFIG_KEYS = ['baseUrl', 'token', 'tokenKind', 'user', 'lastCategory', 'lastPublic'];

/* ---------------- 配置读写 ---------------- */

/** 规整服务端地址：补协议、去尾部斜杠 */
export function normalizeBaseUrl(value) {
  const trimmed = String(value || '').trim().replace(/\/+$/, '');
  if (!trimmed) return '';
  return /^https?:\/\//i.test(trimmed) ? trimmed : `http://${trimmed}`;
}

/** 读取扩展配置 */
export async function readConfig() {
  const raw = await chrome.storage.local.get(CONFIG_KEYS);
  return {
    baseUrl: normalizeBaseUrl(raw.baseUrl) || DEFAULT_BASE_URL,
    token: typeof raw.token === 'string' ? raw.token : '',
    tokenKind: raw.tokenKind || '',
    user: raw.user || null,
    lastCategory: raw.lastCategory || null,
    lastPublic: typeof raw.lastPublic === 'number' ? raw.lastPublic : null,
  };
}

/** 合并写入扩展配置 */
export async function writeConfig(patch) {
  await chrome.storage.local.set(patch);
}

/** 清除登录态（保留服务端地址） */
export async function clearAuth() {
  await chrome.storage.local.remove(['token', 'tokenKind', 'user', 'lastCategory', 'lastPublic']);
}

/** 是否已完成账号配置 */
export function isConfigured(config) {
  return Boolean(config && config.token);
}

/* ---------------- 键名规整 ---------------- */

function normKey(key) {
  if (key.indexOf('_') >= 0) {
    return key.replace(/_([a-z0-9])/g, (_, c) => c.toUpperCase());
  }
  return key.charAt(0).toLowerCase() + key.slice(1);
}

/** 递归把 snake_case / PascalCase 键名统一为 camelCase */
export function norm(value) {
  if (Array.isArray(value)) return value.map(norm);
  if (value && typeof value === 'object') {
    const out = {};
    for (const [key, val] of Object.entries(value)) {
      out[normKey(key)] = norm(val);
    }
    return out;
  }
  return value;
}

/* ---------------- 错误类型 ---------------- */

/** 业务/网络错误：message 为可直接展示给用户的中文提示 */
export class ApiError extends Error {
  constructor(message, code = 0) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
  }

  /** 是否为未登录 / 令牌失效 */
  get isAuthError() {
    return this.code === 401;
  }
}

/* ---------------- 请求核心 ---------------- */

async function request(path, options = {}) {
  const {
    method = 'GET',
    body,
    auth = true,
    config,
    timeout = 15000,
  } = options;

  const cfg = config || (await readConfig());
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (auth && cfg.token) headers['Authorization'] = `Bearer ${cfg.token}`;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);

  let response;
  try {
    response = await fetch(cfg.baseUrl + path, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: controller.signal,
    });
  } catch (error) {
    if (error && error.name === 'AbortError') {
      throw new ApiError('请求超时，请检查服务端地址是否正确', 0);
    }
    throw new ApiError('无法连接服务端，请检查地址与网络', 0);
  } finally {
    clearTimeout(timer);
  }

  const text = await response.text();
  let payload;
  try {
    payload = JSON.parse(text);
  } catch {
    throw new ApiError(`服务端返回了非 JSON 响应（HTTP ${response.status}）`, response.status);
  }

  const envelope = norm(payload);
  if (!envelope || typeof envelope.code !== 'number') {
    throw new ApiError(`服务端响应格式不正确（HTTP ${response.status}）`, response.status);
  }
  if (envelope.code !== 200) {
    throw new ApiError(envelope.msg || `请求失败（${envelope.code}）`, envelope.code);
  }
  return envelope.data;
}

/* ---------------- 业务接口 ---------------- */

export const api = {
  /** 站点状态（无需认证），用于设置页的连通性自检 */
  initStatus(config) {
    return request('/api/init_status', { auth: false, config });
  },

  /** AI 启用状态（无需认证），用于决定「AI分类」按钮是否可用 */
  aiStatus(config) {
    return request('/api/ai_status', { auth: false, config });
  },

  /**
   * AI 网站分类：传入页面地址，返回 { name }（仅一个分类名，不落库）。
   * AI 推理耗时较长，超时放宽到 30s。
   */
  aiClassify(url, config) {
    return request('/api/tools/ai-classify', {
      method: 'POST',
      body: { url },
      config,
      timeout: 30000,
    });
  },

  /**
   * 用户名密码登录，返回 { token, user }。
   * 令牌类型固定为 session：JWT 有效期 7 天，过期后需重新登录。
   */
  async login(username, password, config) {
    const data = await request('/api/login', {
      method: 'POST',
      body: { username, password },
      auth: false,
      config,
    });
    const token = (data && data.token) || '';
    if (!token) {
      throw new ApiError('登录成功但响应中缺少令牌');
    }
    return { token, user: (data && data.user) || null };
  },

  /** 当前账号信息（含 linkPublicDefault，即账号的「新建节点默认公开」开关） */
  me(config) {
    return request('/api/auth/me', { config });
  },

  /** 分类树：一级分类数组，二级在 children 中 */
  categories(config) {
    return request('/api/v1/categories', { config });
  },

  /** 新建分类（parentId=0 为一级分类） */
  createCategory(payload, config) {
    return request('/api/categories', { method: 'POST', body: payload, config });
  },

  /**
   * 收藏当前页面。
   * 返回 { id, created, isPublic, url }：
   * created=false 表示该地址已收藏过（后端按 URL 查重）；
   * isPublic 是后端最终落库的公开状态，所属分类为私有时会被强制降级为私有。
   */
  addLink(payload, config) {
    return request('/api/v1/add_link', { method: 'POST', body: payload, config });
  },
};
