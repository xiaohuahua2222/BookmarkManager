/* ============================================================
 * background.js — 后台服务（MV3 service worker）
 *
 * 职责：注册右键菜单，用「上次在弹窗里选择的目录与可见性」快速收藏，
 * 并通过角标 + 系统通知反馈结果，不打断用户当前浏览。
 * ============================================================ */

import { api, ApiError, isConfigured, readConfig } from './api.js';

const MENU_PAGE = 'bm-save-page';
const MENU_LINK = 'bm-save-link';

/* ---------------- 右键菜单 ---------------- */

chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeText({ text: '' });

  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_PAGE,
      title: '收藏本页到书签库',
      contexts: ['page'],
    });
    chrome.contextMenus.create({
      id: MENU_LINK,
      title: '收藏此链接到书签库',
      contexts: ['link'],
    });
  });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.action.setBadgeText({ text: '' });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== MENU_PAGE && info.menuItemId !== MENU_LINK) return;

  const isLink = info.menuItemId === MENU_LINK;
  const url = isLink ? info.linkUrl : info.pageUrl || (tab && tab.url) || '';
  const title = isLink ? '' : (tab && tab.title) || '';

  // 不 await：右键回调无需保持驻留，内部自行处理错误
  quickSave(url, title);
});

/* ---------------- 快速收藏 ---------------- */

async function quickSave(url, pageTitle) {
  if (!url || !/^https?:\/\//i.test(url)) {
    await notify('无法收藏', '这个地址不是普通网页链接。');
    return;
  }

  const config = await readConfig();
  if (!isConfigured(config)) {
    await notify('还没连接书签库', '请先打开扩展设置，填写服务端地址并登录。');
    chrome.runtime.openOptionsPage();
    return;
  }

  const last = config.lastCategory;
  if (!last || !Number(last.id)) {
    await notify('还没有可用目录', '先点一次扩展图标收藏当前页面，之后右键就能收藏到同一目录。');
    return;
  }

  const categoryType = last.type === 'l2' ? 'l2' : 'l1';
  const categoryId = Number(last.id);
  const isPublic =
    typeof config.lastPublic === 'number'
      ? config.lastPublic
      : Number(config.user && config.user.linkPublicDefault) === 0
        ? 0
        : 1;

  try {
    const result = await api.addLink(
      {
        title: String(pageTitle || '').trim() || hostOf(url),
        url,
        description: '',
        category_type: categoryType,
        category_id: categoryId,
        is_public: isPublic,
      },
      config
    );

    const path = await describeCategory(config, categoryType, categoryId);
    const created = !result || result.created !== false;

    if (created) {
      await flashBadge('已存', '#2f9e44');
      await notify('已收藏', `已保存到「${path}」`);
    } else {
      await flashBadge('已存在', '#8a8f99');
      await notify('之前已经收藏过', '同一地址在书签库里已存在，本次没有重复添加。');
    }
  } catch (error) {
    if (error instanceof ApiError && error.isAuthError) {
      await flashBadge('失效', '#e5484d');
      await notify('登录已失效', '请打开扩展设置重新登录。');
      return;
    }
    await flashBadge('失败', '#e5484d');
    await notify('收藏失败', error.message);
  }
}

/** 把分类 ID 还原成「一级 / 二级」便于通知展示；查询失败时退回通用文案 */
async function describeCategory(config, categoryType, categoryId) {
  try {
    const tree = await api.categories(config);
    const list = Array.isArray(tree) ? tree : [];

    if (categoryType === 'l2') {
      for (const l1 of list) {
        const hit = (l1.children || []).find((child) => Number(child.id) === categoryId);
        if (hit) return `${l1.name} / ${hit.name}`;
      }
    }
    const l1 = list.find((item) => Number(item.id) === categoryId);
    return l1 ? l1.name : '上次使用的目录';
  } catch {
    return '上次使用的目录';
  }
}

/* ---------------- 反馈 ---------------- */

function hostOf(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

async function flashBadge(text, color) {
  await chrome.action.setBadgeBackgroundColor({ color });
  await chrome.action.setBadgeText({ text });

  // service worker 空闲终止阈值约 30 秒，2.5 秒内必定仍存活
  setTimeout(() => {
    chrome.action.setBadgeText({ text: '' });
  }, 2500);
}

function notify(title, message) {
  return chrome.notifications.create({
    type: 'basic',
    iconUrl: chrome.runtime.getURL('icons/icon128.png'),
    title,
    message,
  });
}
